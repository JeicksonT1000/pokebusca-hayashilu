import { Component } from '@angular/core';

@Component({
  selector: 'app-pokemon-footer',
  templateUrl: './pokemon-footer.component.html',
  styleUrls: ['./pokemon-footer.component.css']
})
export class PokemonFooterComponent {

}
